# Projet S7 - S8

Application web dont les buts finaux sont :
- la consultation des données existantes sur les accidents de vélo à Rennes, présentées sous la forme d'une carte interactive et de statistiques.
- la possibilité d'ajouter des données en tant qu'utilisateur en signalant des accidents, des dangers potentiels ou des suggestions d'aménagements.


Membres :

- Erwann Gauthier
- Théo Laminie
- Antoine Rault
- Fanny Shehabi

## Lancer le MVP

Aller dans le répertoire `frontend` du projet.
